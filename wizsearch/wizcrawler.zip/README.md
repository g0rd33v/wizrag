# WizCrawler

A standalone source-discovery and crawl-planning tool. Pairs with any version of WizSearch (V1, V2, V3).

## What it does

You describe what you want to know about. WizCrawler runs a short interview, searches for sources, evaluates them, and produces a `wizcrawl.json` manifest — a ranked list of sources with crawl strategies, fallbacks, and instructions that a WizSearch builder consumes.

**WizCrawler does not fetch documents. It does not build indexes. It plans the crawl.**

## When to use it

- You have a topic but no clear source list
- You want multiple sources federated into one knowledge base
- You need a repeatable, auditable record of what was indexed and why
- You want the indexer to fall back gracefully when a source fails

## When NOT to use it

- You already have a repo or folder — just use WizSearch directly
- One clear source, one pass — overkill

## How to use it

1. Open any top-tier LLM chat (Claude, ChatGPT, Grok, Gemini — anything with strong web search)
2. Paste `wizcrawler.md` as the first message
3. Answer the intake questions (12 questions, grouped, conversational)
4. Receive `wizcrawl.json`
5. Hand that file to your WizSearch builder along with the template for your chosen version

## What you get

A `wizcrawl.json` file with:
- Intake record (your answers — reproducible input)
- Summary (source count, estimated corpus size, predicted topics)
- Ranked source list (must-have / should-have / nice-to-have)
- Crawl strategies with waterfalls (primary method + fallbacks)
- Indexer instructions (build order, retry policy, special handling)
- Alternate sources (reserve pool if corpus comes up thin)

## Separation of concerns

| Tool | Job | Output |
|---|---|---|
| **WizCrawler** | Discovery + planning | `wizcrawl.json` |
| **WizSearch builder** | Fetch + chunk + enrich | `wizindex.json` + `wizsearch.html` |
| **WizSearch runtime** | Query + answer | The search page |

Each tool can run on a different LLM. Use Grok for discovery (strong social/X coverage), Claude for building (best at long-document reasoning), a local model at query time.

## The crawl contract

The strength of this separation is that the manifest is the contract between discovery and building. The indexer reads one file and knows: what to fetch, what order, what to do on failure, what attribution to preserve, what size budget to respect.

When a fetch fails, the indexer does not guess. It consults the `crawl_strategies` array for the next method. When the corpus comes up thin, it consults `alternate_sources`. When it times out, it defers `nice_to_have` and ships what it has.

## Files in this bundle

- `wizcrawler.md` — the template you paste into the LLM
- `wizcrawl.schema.json` — JSON schema for the output (for programmatic validation)
- `README.md` — this file

## Versioning

This is WizCrawler 1.0. Manifest format is stable. Future versions will extend the schema additively — existing `wizcrawl.json` files will remain valid.
