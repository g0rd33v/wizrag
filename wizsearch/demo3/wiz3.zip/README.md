# WizSearch V3 — Build Bundle

You are an LLM reading this file. Your job is to turn a set of sources into a deployed WizSearch V3 knowledge base. Follow this document exactly.

---

## The bundle you're working with

- `README.md` — this file
- `wizsearch.html` — the V3 runtime template. Populate placeholders, output as-is
- `wizindex-manifest.json` — the sharded-index schema template

---

## Step 0 — Check for WizCrawler input

**First thing you do: look at the chat for a `wizcrawl.json` file.**

### If `wizcrawl.json` is present

Parse it. You now have:
- `intake` — the user's configuration decisions
- `sources[]` — the ranked list of sources to crawl
- `indexer_instructions` — how to handle each source
- `fallback_chain` — what to do when things fail
- `alternate_sources[]` — reserve pool if the corpus is thin

Skip straight to Step 2. Do not ask the user any questions.

### If no `wizcrawl.json` is present

You need to run a short intake before you build. Ask the user exactly three questions, grouped in one message:

1. **What is this knowledge base about?** (one sentence)
2. **Are there specific sources you want included?** (URLs, repos, domains — or "you decide")
3. **Any scope limits?** (e.g., "only official docs", "last 12 months only", "include forums" — or "none")

After the user answers, do your own web search to assemble a source list. Aim for 10-30 high-quality sources. Present the list briefly for confirmation, then proceed to Step 2.

**Do not re-run the full WizCrawler intake.** V3 works standalone — keep the questions minimal.

---

## Step 1 — Understand V3

V3 is a chat-first knowledge agent that runs entirely in the browser. Key architectural facts you must honor:

- **Sharded index.** Not one big `wizindex.json`. A manifest plus shards.
- **Embeddings.** Every chunk gets a 384-dim vector, int8-quantized.
- **Three-tier answers.** User picks: API key (remote LLM), local browser LLM (download once), or retrieval-only (no LLM, instant).
- **Chat-first UI.** Not search-first. The page opens as a conversation.
- **Static output.** No backend. Deploys to GitHub Pages, Netlify, any static host.

---

## Step 2 — Scan, chunk, enrich

### Scanning

For every source, fetch and parse:
- Markdown / text / reStructuredText → plain text
- HTML → extracted article content (skip nav, footer, ads)
- PDFs → extracted text (OCR only if extraction yields near-nothing)

Skip: code, binaries, node_modules, build output, images, test fixtures.

### Chunking

Split each document into **semantic units**:
- 400-1200 tokens per chunk (hard cap 2000)
- Self-contained — readable without adjacent context
- Start and end on paragraph or section boundaries
- Long documents: split at H2 or H3 headings

### Enriching every chunk

Each chunk gets these fields:

- `id` — unique, stable (e.g., `chunk_0042`)
- `source` — canonical URL
- `source_label` — human-readable ("1996 Letter — On intrinsic value")
- `topic` — must match a topic name in the manifest
- `title` — 3-8 word headline
- `text` — the full chunk text (markdown OK)
- `keywords` — 4-14 precise terms. Include every named entity (people, products, places, subsidiaries). Fuse weights keywords (0.25) higher than text (0.12) — entities in text alone may miss
- `synonyms` — 3-8 alternatives the user might search with
- `acronyms` — `{ "GAAP": "Generally Accepted Accounting Principles" }`
- `alt_phrasings` — 2-4 natural-language question forms

### Clustering into topics

Group chunks into 5-15 topics. Topics are themes a user would search for, not one-per-year or one-per-source. Avoid single-chunk topics.

---

## Step 3 — Generate embeddings

For every chunk, compute a 384-dim embedding using `Xenova/all-MiniLM-L6-v2` or an equivalent (BGE-small, gte-small all work — just be consistent).

### How you get embeddings

You have three paths, in order of preference:

1. **You have an embedding API available** (OpenAI `text-embedding-3-small`, Voyage, Cohere) — use it. Note: these produce different dimensions (1536, 1024, etc.). Use them if available and record the actual dim in the manifest.
2. **You can run transformers.js in a sandboxed Python/JS environment** — use `Xenova/all-MiniLM-L6-v2` (384-dim, standard).
3. **You can only generate text** — output the chunks without embeddings and add `"embeddings_pending": true` to the manifest. The runtime will compute embeddings on first load (slow but functional).

### Quantizing to int8

Once you have float embeddings per chunk:
1. For each shard (group of chunks), find `min` and `max` across all values in all vectors in that shard
2. Compute `scale = (max - min) / 255` and `zero_point = -min / scale`
3. Each float `f` becomes int8: `round(f / scale + zero_point)` clamped to `[-128, 127]`
4. Store `scale` and `zero_point` once per shard in the manifest
5. The runtime reverses: `float_value = (int8_value - zero_point) * scale`

This is symmetric quantization with per-shard scaling. Good enough for top-10 retrieval.

---

## Step 4 — Shard the output

### Shard by size

Target each shard at **~50 chunks** or **~500KB of JSON**, whichever comes first.

### Shard layout

Output a folder structure:

```
wiz3-build/
├── wizsearch.html
├── wizindex-manifest.json
├── chunks/
│   ├── shard-001.json
│   ├── shard-002.json
│   └── shard-003.json
└── embeddings/
    ├── shard-001.bin
    ├── shard-002.bin
    └── shard-003.bin
```

### Shard file format — `chunks/shard-NNN.json`

```json
{
  "shard_id": "shard-001",
  "chunks": [
    { "id": "chunk_0001", "source": "...", "source_label": "...", "topic": "...", "title": "...", "text": "...", "keywords": [], "synonyms": [], "acronyms": {}, "alt_phrasings": [] }
  ]
}
```

### Embedding file format — `embeddings/shard-NNN.bin`

Binary file. Contiguous int8 values. If the shard has 50 chunks and the embedding dim is 384, the file is exactly `50 × 384 = 19200` bytes. Chunk order in the binary matches chunk order in the JSON shard.

If you cannot write binary files directly (some LLM build environments can't), output the int8 values as a base64 string in the JSON shard under a `"embeddings_b64"` field. The runtime handles both.

---

## Step 5 — Populate the manifest

Open `wizindex-manifest.json`. It's a template with `{{PLACEHOLDER}}` tokens. Replace them.

Required fields:

- `project` — the project name (e.g., "Anthropic Skills Archive")
- `description` — one-line description, 80-140 chars
- `built_at` — ISO 8601 timestamp
- `topic` — the subject (from the intake)
- `accent_color` — hex without `#`, default `"2563eb"`
- `embedding_model` — model name used (`"Xenova/all-MiniLM-L6-v2"`)
- `embedding_dim` — integer (`384`)
- `embedding_dtype` — `"int8"` or `"float32"`
- `stats` — `files`, `chunks`, `topics`, `total_characters`, `index_size_kb`
- `topics[]` — list of topic objects with `name`, `description` (80-140 chars), `keywords[]`, `chunk_count`
- `sources[]` — list of source objects with `label`, `url`, `type`
- `shards[]` — list of shard references with `id`, `chunks_url`, `embeddings_url`, `chunk_count`, `built_at`, `topics[]`, `embedding_scale`, `embedding_zero_point`
- `suggested_questions[]` — 3-5 example questions the user can click as starting points

---

## Step 6 — Populate the HTML template

Open `wizsearch.html`. Find the `{{PLACEHOLDER}}` tokens and replace them with values from the manifest. The HTML fetches the manifest at runtime, but it also embeds a few values statically so raw-fetch LLMs can see them without running JavaScript.

Placeholders:

- `{{PROJECT_NAME}}` — e.g., "Anthropic Skills Archive"
- `{{PROJECT_DESCRIPTION}}` — the one-liner
- `{{ACCENT_COLOR}}` — hex without `#`
- `{{BUILT_AT}}` — human-readable date, e.g., "19 April 2026"
- `{{STATS_CHUNKS}}`, `{{STATS_SOURCES}}`, `{{STATS_TOPICS}}` — integers
- `{{FIRST_MESSAGE_HTML}}` — the first assistant message as rendered HTML. This is critical — it's what the user sees on page load. See template in the HTML
- `{{SUGGESTED_QUESTIONS_JSON}}` — JSON array of 3-5 starter questions
- `{{TOPICS_STATIC_HTML}}` — static HTML listing the topics so raw-fetch LLMs can read them without JavaScript

---

## Step 7 — Output the bundle

Package everything into a zip named `wiz3-build.zip`:

```
wiz3-build.zip
├── wizsearch.html
├── wizindex-manifest.json
├── chunks/ (folder with shard-*.json files)
└── embeddings/ (folder with shard-*.bin or embedded in JSON)
```

### Deployment instructions (include in your output message)

Tell the user: unzip into a folder, push to a GitHub repo, enable GitHub Pages on the main branch root. Visit `https://[user].github.io/[repo]/wizsearch.html`.

Or simpler: upload the whole folder to Netlify Drop, S3, or any static host.

---

## Constraints you must honor

1. **Lowercase filenames.** `wizsearch.html`, `wizindex-manifest.json`, `chunks/shard-001.json`, `embeddings/shard-001.bin`.
2. **Do not modify the HTML's `<style>`, `<script>`, or the BUILD INSTRUCTIONS comment inside it.** Only replace placeholders.
3. **Do not alter the manifest schema.** You may add fields the runtime ignores; do not remove required fields.
4. **Preserve source attribution.** Every chunk must have a valid `source` URL or a `source_label` the user can trace back.
5. **Honor the WizCrawler `indexer_instructions.special_handling`** if a `wizcrawl.json` was provided. Those are authoritative.
6. **If a source fails to fetch:** try the next strategy in its `crawl_strategies` (if using WizCrawler), else skip and log. Do not fake content.
7. **If the corpus ends up smaller than 20 chunks:** tell the user, offer to broaden sources. Don't ship a three-chunk knowledge base silently.
8. **Generate `suggested_questions` thoughtfully.** They should be questions the index can actually answer well. Mix broad ("What is X?") with specific ("How does X handle Y?").

---

## One honest note

V3 is more complex than V1 and V2. Building the full sharded + embedded bundle in a single LLM response may exceed output limits for large corpora. If you hit limits:

- Ship the manifest and first 2-3 shards in response 1
- Tell the user: "Continue?" and generate remaining shards in subsequent turns
- Final turn: give them the complete zip

Better a staged delivery than a truncated one.

---

## Begin

If `wizcrawl.json` is in the chat, parse it and go to Step 2.
Otherwise, ask the three intake questions above.
