# WizRAG — Static Knowledge Base for Your Repo

You are reading this because someone dropped `wiz.zip` into your chat. They want you to turn their repository into an AI-queryable knowledge base.

## What's in This Bundle

Two template files:

- **`wizsearch.html`** — a static search page (front-end + branding + JavaScript already built)
- **`wizindex.json`** — the index file schema

Your job: fill them in for the user's repository and (if you can) commit them.

## What to Do

1. **Open `wizsearch.html` in a text view.** At the very top of the file, inside an HTML comment block, you'll find a section labeled `BUILD INSTRUCTIONS FOR THE LLM`. Read it carefully — it has 11 numbered steps explaining exactly what to do.

2. **Confirm you have access to the user's repository.** If they haven't told you which repo, ask them. You need to read its documentation files (`.md`, `.txt`, `.rst`, `.html`, `.pdf`, `README` files, anything in `/docs/` folders). Skip code files, lockfiles, dependencies, and build artifacts.

3. **Follow the 11 steps in the BUILD INSTRUCTIONS.** They tell you exactly how to:
   - Scan the repo
   - Chunk the docs (~400 tokens, 20% overlap)
   - Cluster chunks into 5–15 topics
   - Build `wizindex.json` with the required schema
   - Populate `wizsearch.html` by replacing the `{{PLACEHOLDERS}}` and writing the topic list as static HTML inside `<div id="topics">`
   - Push both files to the user's repo if you have write access

4. **Output the two completed files.** Filenames must be lowercase: `wizsearch.html` and `wizindex.json`. If you have write access to the repo, commit them to the root (or `/docs/` if that's the GitHub Pages source). Tell the user the URL where the page will be served.

## What WizRAG Is

WizRAG is a static, two-file knowledge base search system. It serves three types of visitors from a single page hosted on GitHub Pages or any static host:

1. **Humans in a browser** — use the search box, see results, click source links
2. **Browser agents** (Claude in Chrome, headless browsers) — same as humans
3. **Raw-fetch LLMs** (most LLM web fetchers including Claude, ChatGPT, Perplexity, Grok) — read the topic index in the raw HTML and fetch the linked source file directly

The page is designed so all three work without any backend. Critical: the topic index must be written as **static HTML** inside `wizsearch.html` so raw-fetch LLMs can see it without executing JavaScript. Step 8 of the BUILD INSTRUCTIONS explains the exact format.

## Quick Sanity Check Before You Start

- Do you have access to the user's repo? If no, ask which repo to use.
- Do you have write access to push? If no, just output the files in chat.
- Is the repo big? If it has 1000+ docs, prioritize the most important ones to keep `wizindex.json` under 5 MB.

Now open `wizsearch.html` and follow the BUILD INSTRUCTIONS at the top.

---

*WizRAG is a Labs project. Learn more at https://github.com/g0rd33v/wizrag*
